#!C:\Users\hafil\AppData\Local\Programs\Python\Python312/python.exe
print ("Content-type:text/html\r\n\r\n")
from db import *
print ("""<!DOCTYPE html>
<html lang='en'>
<head><meta charset='UTF-8'>
<title>AgroCulture</title>
<meta http-equiv='content-type' content='text/html; charset=utf-8' />
<meta name='description' content='' />
<meta name='keywords' content='' />
<link href='bootstrap\css\bootstrap.min.css' rel='stylesheet'>
<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
<script src='bootstrap\js\bootstrap.min.js'></script>""")

print ("""<link rel='stylesheet' href='login.css'/>
<script src='js/jquery.min.js'></script>
<script src='js/skel.min.js'></script>
<script src='js/skel-layers.min.js'></script>
<script src='js/init.js'></script>
<noscript>
<link rel='stylesheet' href='css/skel.css' />
<link rel='stylesheet' href='css/style.css' />
<link rel='stylesheet' href='css/style-xlarge.css' />
</noscript>""")

print ("""</head>
<body class>""")
from menu import *

print ("""<section id='main' class='wrapper style1 align-center' >
<div class='container'>
<h2>Welcome to digital market</h2>
<h3><b>Order Details</h3>""")


if(category=="farmer"):
    print ("<table style='border-style:solid;border-width:1px;border-color:black;'>")
    print ("<tr style='color:black';><td colspan='10'>")
    print ("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print ("</td></tr>")
    print ("<tr style='color:black; font-size:20px;'>")
    print ("<td>Order Id</td>")
    print ("<td>Product Id</td>")
    print ("<td>Product Name</td>")
    print ("<td>Buyer Id</td>")
    print ("<td>Buyer Name</td>")
    print ("<td>Quantity</td>")
    print ("<td>Cost</td>")
    print ("<td>Contact No</td>")
    print ("<td>Email Id</td>")
    print ("<td>Address</td>")
    print ("<td>Action</td>")
    print ("</tr>")
    print ("<tr style='color:black';><td colspan='10'>")
    print ("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print ("</td></tr>")
    select="select id,pname from product where email='%s'"%(email)
    if(cursor.execute(select)>0):
        results=cursor.fetchall()
        for row in results:
            pid=row[0]
            pname=row[1]
            sql="select * from order_details where pid=%d"%(int(pid))
            if(cursor.execute(sql)>0):
                results=cursor.fetchone()
                orderid=results[0]
                pid=results[1]
                uid=results[3]
                uname=results[4]
                email=results[5]
                mobile=results[6]
                city=results[7]
                pincode=results[8]
                address=results[9]
                total=results[10]
                status=results[11]
                quantity=results[2]
                print ("<tr style='color:blue; font-size:20px;'><td>")
                print (orderid)
                print ("</td><td>")
                print (pid)
                print ("</td><td>")
                print (pname)
                print ("</td><td>")
                print (uid)
                print ("</td><td>")
                print (uname)
                print ("</td><td>")
                print (str(quantity)+" Kg")
                print ("</td><td>")
                print ("Rs. "+str(total))
                print ("</td><td>")
                print (mobile)
                print ("</td><td>")
                print (email)
                print ("</td><td>")
                print (str(address)+"<br>"+str(city)+"<br>"+str(pincode))
                print ("</td><td>")
                if(status=="Confirmed"):
                    print ("<a href='cancel_order.py?oid=%s&status=Cancelled By Owner'><font color='black'>Cancel</a>"%(orderid))
                    print ("<a href='cancel_order.py?oid=%s&status=Delivered'><font color='black'>Delivered</a>"%(orderid))
                elif(status=="Cancelled By Owner"):
                    print ("Cancelled By You")
                elif(status=="Delivered"):
                    print ("Delivered")
                else:
                    print ("Cancelled By Buyer")
                print ("</td></tr>")
                print ("<tr style='color:black';><td colspan='10'>")
                print ("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
                print ("</td></tr>")
else:
    print ("<table style='border-style:solid;border-width:1px;border-color:black;'>")
    print ("<tr style='color:black';><td colspan='10'>")
    print ("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print ("</td></tr>")
    print ("<tr style='color:black; font-size:20px;'>")
    print ("<td>Order Id</td>")
    print ("<td>Product Id</td>")
    print ("<td>Product Name</td>")
    print ("<td>Quantity</td>")
    print ("<td>Cost</td>")
    print ("<td>Shipment Details</td>")
    print ("<td>Owner Name</td>")
    print ("<td>Owner Phone No</td>")
    print ("<td>Owner Email Id</td>")
    print ("<td>Action</td>")
    print ("</tr>")
    print ("<tr style='color:black';><td colspan='10'>")
    print ("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print ("</td></tr>")
    select="select * from order_details where email='%s'"%(email)
    if(cursor.execute(select)>0):
        results=cursor.fetchall()
        for row in results:
            orderid=row[0]
            pid=row[1]
            total=row[10]
            status=row[11]
            quantity=row[2]
            email=row[5]
            mobile=row[6]
            city=row[7]
            pincode=row[8]
            address=row[9]
            sql="select * from product where id=%d"%(int(pid))
            if(cursor.execute(sql)>0):
                results=cursor.fetchone()
                pname=results[5]
                owneremail=results[1]
                ownername=results[2]
                ownerphone=results[3]
                print ("<tr style='color:blue; font-size:20px;'><td>")
                print (orderid)
                print ("</td><td>")
                print (pid)
                print ("</td><td>")
                print (name)
                print ("</td><td>")
                print (str(quantity)+" Kg")
                print ("</td><td>")
                print ("Rs. "+str(total))
                print ("</td><td>")
                print (str(address)+"<br>"+str(city)+"<br>"+str(pincode)+"<br>Ph:"+str(mobile))
                print ("</td><td>")
                print (ownername)
                print ("</td><td>")
                print (ownerphone)
                print ("</td><td>")
                print (owneremail)
                print ("</td><td>")
                if(status=="Confirmed"):
                    print ("<a href='cancel_order.py?oid=%s&status='Cancelled By Buyer'><font color='black'>Cancel Order</a>"%(orderid))
                elif(status=="Cancelled By Buyer"):
                    print ("Cancelled By You")
                elif(status=="Delivered"):
                    print ("Delivered")
                else:
                    print ("Cancelled By Owner")
                print ("</td></tr>")
                print ("<tr style='color:black';><td colspan='10'>")
                print ("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
                print ("</td></tr>")
            

print ("<table>")

print ("</section>")

print ("""</body>
</html>""")
