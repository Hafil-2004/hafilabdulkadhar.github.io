function readURL1(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('#blah1')
.attr('src', e.target.result);
};

reader.readAsDataURL(input.files[0]);
}
}
function readURL2(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('#blah2')
.attr('src', e.target.result);
};

reader.readAsDataURL(input.files[0]);
}
}

function readURL3(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('#blah3')
.attr('src', e.target.result);
};

reader.readAsDataURL(input.files[0]);
}
}
function readURL4(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('#blah4')
.attr('src', e.target.result);
};

reader.readAsDataURL(input.files[0]);
}
}
function readURL5(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('#blah5')
.attr('src', e.target.result);
};

reader.readAsDataURL(input.files[0]);
}
}
function readURL6(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('#blah6')
.attr('src', e.target.result);
};

reader.readAsDataURL(input.files[0]);
}
}