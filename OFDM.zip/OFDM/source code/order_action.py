#!C:\Users\hafil\AppData\Local\Programs\Python\Python312/python.exe
print ("Content-type:text/html\r\n\r\n")
from db import *
uid=form.getvalue('uid')
pid=form.getvalue('pid')
name=form.getvalue('name')
city=form.getvalue('city')
email=form.getvalue('email')
mobile=form.getvalue('mobile')
quantity=form.getvalue('quantity')
pincode=form.getvalue('pincode')
addr=form.getvalue('addr')
cost=form.getvalue('cost')
select="select ifnull(max(id),0) from order_details"
if(cursor.execute(select)>0):
    results=cursor.fetchone()
    oid=int(results[0])+1
insert="insert into order_details values(%d,%d,%d,%d,'%s','%s','%s','%s',%d,'%s',%d,'Confirmed')"%(oid,int(pid),int(quantity),int(uid),name,email,mobile,city,int(pincode),addr,int(cost))
if(cursor.execute(insert)>0):
    db.commit()
    print ("<script>alert('Order Placed Successfully');location.href='orderdetails.py';</script>")
else:
    print ("<script>alert('Failed to Confirm');location.href='productmenu.py';</script>")
