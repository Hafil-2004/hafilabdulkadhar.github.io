import cgi
form=cgi.FieldStorage()
import MySQLdb
db=MySQLdb.connect("127.0.0.1","root","hafil","agroculture")
cursor=db.cursor()
select="select name,category,email from tbl_session"
if(cursor.execute(select)>0):
    results=cursor.fetchone()
    name=results[0]
    category=results[1]
    email=results[2]

