print ("""<!-- Footer -->
<footer id='footer'>
<div class='container'>
<div class='row'>
<section class='4u 6u(medium) 12u$(small)'>
<h3>Welcome to Digital Market</h3>

<ul class='alt'>
<li>All marketing efforts that use an electronic device or the internet. Businesses leverage digital channels such as search engines, social media, email, and their websites to connect with current and prospective customers.</li>
</ul>
</section>
<section class='4u 6u$(medium) 12u$(small)'>
<h3>Agroculture</h3>
<p>Your product Our market !!!</p>
<ul class='alt'>
<li>AgroCulture is e-commerce trading platform for grains & grocerries of farmers  to the customers. It also involves payment accomplishment of the goods and services via an online platform.  People also call it internet retailing. Online Farmer's Digital Market constitutes a perfect example of e-commerce in the realm of agricultural marketing in India</li>
</ul>
</section>
<section class='4u$ 12u$(medium) 12u$(small)'>
<h3>Contact Us</h3>
<ul class='icons'>
<li><a href='#' class='icon rounded fa-twitter'><span class='label'>Twitter</span></a></li>
<li><a href='#' class='icon rounded fa-facebook'><span class='label'>Facebook</span></a></li>
<li><a href='#' class='icon rounded fa-pinterest'><span class='label'>Pinterest</span></a></li>
<li><a href='#' class='icon rounded fa-google-plus'><span class='label'>Google+</span></a></li>
<li><a href='#' class='icon rounded fa-linkedin'><span class='label'>LinkedIn</span></a></li>
</ul>
<ul class='tabular'>
<li>
<h3>Address</h3>
street name<br>
city,state,pincode
</li>
<li>
<h3>Mail</h3>
<a href='#'>agroculture@gmail.com</a>
</li>
<li>
<h3>Phone</h3>
(000) 000-0000
</li>
</ul>
</section>
</div>
<ul class='copyright'>
<li>&copy; 2019. All rights reserved.</li>

</ul>
</div>
</footer>
""")
