#!C:\Users\hafil\AppData\Local\Programs\Python\Python312/python.exe
print ("Content-type:text/html\r\n\r\n")
from db import *
print ("""<!DOCTYPE html>
<html>
<head><title>AgroCulture: Transaction</title>
<meta lang='eng'>
<meta charset='UTF-8'>
<title>AgroCulture</title>
<meta http-equiv='content-type' content='text/html; charset=utf-8' />
<meta name='description' content='' />
<meta name='keywords' content='' />
<link href='bootstrap\css\bootstrap.min.css' rel='stylesheet'>
<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
<script src='bootstrap\js\bootstrap.min.js'></script>""")
##		<!--[if lte IE 8]><script src='css/ie/html5shiv.js'></script><![endif]-->
print ("""<script src='js/jquery.min.js'></script>
<script src='js/skel.min.js'></script>
<script src='js/skel-layers.min.js'></script>
<script src='js/init.js'></script>
<link rel='stylesheet' href='Blog/commentBox.css' />
<noscript>
<link rel='stylesheet' href='css/skel.css' />
<link rel='stylesheet' href='css/style.css' />
<link rel='stylesheet' href='css/style-xlarge.css' />
</noscript></head><body>""")
from menu import *
pid=form.getvalue('pid')
quantity=form.getvalue('quantity')
select="select pcost,quantity from product where id=%d"%(int(pid))
if(cursor.execute(select)>0):
    results=cursor.fetchone()
    pcost=int(results[0])
    pq=int(results[1])
    if(pq<int(quantity)):
        print ("<script>alert('product out of stock');location.href='productmenu.py';</script>")
    total=pcost*int(quantity)
select="select * from user where email='%s'"%(email)
if(cursor.execute(select)>0):
    results=cursor.fetchone()
    uid=results[0]
    phone=results[5]
print ("""<section id='main' class='wrapper' >
<div class='container'>
<center>
<h2>Transaction Details</h2></center>
<section id='two' class='wrapper style2 align-center'>
<div class='container'><center>""")
print ("<form method='post' action='order_action.py' style='border: 1px solid black; padding: 15px;'>")
print ("<input type='hidden' name='uid' value='%s'>"%(uid))
print ("<input type='hidden' name='pid' value='%s'>"%(pid))
print ("""<center><div class='row uniform'>
<div class='6u 12u$(xsmall)'>""")
print ("Name:<input type='text' name='name' id='name' value='%s' placeholder='Name' ></div>"%(name))
print ("""<div class='6u 12u$(xsmall)'>""")
print ("Product Quantity(in kg):<input type='text' name='quantity' id='quantity' value='%s' readonly>"%(quantity))
print ("""</div>

<div class='6u 12u$(xsmall)'>
City: <input type='text' name='city' id='city' value='' placeholder='City' required/>
</div>
<div class='6u 12u$(xsmall)'>""")
print ("Mobile: <input type='text' name='mobile' id='mobile' value='%s' placeholder='Mobile Number' required></div>"%(phone))
print ("<div class='6u 12u$(xsmall)'>")
print ("Email: <input type='email' name='email' id='email' value='%s' placeholder='Email' readonly>"%(email))
print ("""</div>
<div class='4u 12u$(xsmall)'>
Pincode: <input type='text' name='pincode' id='pincode' value='' placeholder='Pincode' required/></div>
<div class='8u 12u$(xsmall)'>
Address: <textarea name='addr' id='addr' placeholder='Address' style='width:80%' required/></textarea>
</div>""")
print ("<div class='8u 12u$(xsmall)'>")
print ("Total Amount:")
print ("<input type='text' name='cost'  value='%s' readonly>"%(total))
print ("</div></div><br />")
print ("""<p><input type='submit' value='Confirm Order' /></p>
</center>
</form>
</fieldset>""")

