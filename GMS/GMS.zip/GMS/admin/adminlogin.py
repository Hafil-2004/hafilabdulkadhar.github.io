#!C:\Users\hafil\AppData\Local\Programs\Python\Python312/python.exe
print("Content-Type:text/html\n\r")
import cgi
import pymysql
form=cgi.FieldStorage()
username=form.getvalue('username')
password=form.getvalue('password')
dbcon=pymysql.connect(host="localhost",user="root",password="hafil",database="cms",charset="utf8")
if(dbcon):
    cursor=dbcon.cursor()
    try:
        existsquery="select * from admin where username='%s' and password='%s'"%(username,password)
        if(cursor.execute(existsquery)>0):
            res=cursor.fetchone()
            execute=cursor.execute(existsquery)
            dbcon.commit()
            print("<script>alert('Logged In Successfully');location.href='notprocess-complaint.py';</script>")
        else:
            dbcon.rollback()
            print("<script>alert('Invalid username and password');location.href='index.py';</script>")
    except Exception as e:
        print(e)
else:
     print("<script>alert('DB Error');location.href='index.py';</script>")
    
            
